import { combineReducers } from 'redux-immutable';
import todo from './todoReducers';// import routes from './routes';

const rootReducer = combineReducers({
  todo,
});

export default rootReducer;
