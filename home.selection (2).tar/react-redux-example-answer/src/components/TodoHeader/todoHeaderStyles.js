export default {
    todoHeader: {
        color: 'red',
    },
};