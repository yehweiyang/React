import React from 'react';
import styles from './todoHeaderStyles';

class TodoHeader extends React.Component {
    
    constructor(props) {
        super(props) ;
        console.log(props) ;
    }
    
    render() {
        return (
            <div>
                <h1 style={styles.todoHeader}>TodoHeader</h1>
                <input value={this.props.todo.get('text')}
                    onChange={this.props.onChangeText}
                    className="form-control"
                    type="text"/>
                <button className="btn btn-lg" 
                    onClick={this.props.onCreateTodo}>新增代辦事項</button>
            </div>
        );
    }
}

export default TodoHeader;