import React from 'react';

// 使用 ES6 Class Component 寫法
class TodoList extends React.Component {
    
    constructor(props) {
        super(props) ;
    }
    
    render() {
        return (
            <div>
                <h1>TodoList</h1>
                <ul>
                    {this.props.todos.map((todo, index) => (
                        <li key={index}>
                            <p>{todo.get('text')}</p>
                            <button onClick={this.props.onDeleteTodo(index)}>X</button>
                        </li>
                    ))}
                </ul>
            </div>
        );
    }
}

export default TodoList ;